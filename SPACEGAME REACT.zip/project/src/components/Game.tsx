import React, { useEffect, useRef } from 'react';
import { useGameLoop } from '../hooks/useGameLoop';
import { Player } from '../game/Player';
import { GameState } from '../game/GameState';

export function Game() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameState = useRef<GameState>(new GameState());

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = 800;
    canvas.height = 600;

    // Initialize game state
    gameState.current.init(canvas);

    // Handle keyboard input
    const handleKeyDown = (e: KeyboardEvent) => {
      gameState.current.handleKeyDown(e.code);
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      gameState.current.handleKeyUp(e.code);
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  useGameLoop((deltaTime) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    gameState.current.update(deltaTime);
    gameState.current.render(ctx);
  });

  return (
    <div className="relative rounded-lg overflow-hidden shadow-2xl">
      <canvas
        ref={canvasRef}
        className="bg-black w-full"
        style={{ aspectRatio: '800/600' }}
      />
      <div className="absolute top-4 left-4 text-white">
        <p>Score: {gameState.current.score}</p>
      </div>
    </div>
  );
}