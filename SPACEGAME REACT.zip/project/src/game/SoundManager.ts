import { Howl } from 'howler';

export class SoundManager {
  private sounds: {
    jump: Howl;
    collect: Howl;
    hit: Howl;
  };

  constructor() {
    this.sounds = {
      jump: new Howl({
        src: ['https://assets.codepen.io/21542/howler-push.mp3'],
        volume: 0.2
      }),
      collect: new Howl({
        src: ['https://assets.codepen.io/21542/howler-coin.mp3'],
        volume: 0.2
      }),
      hit: new Howl({
        src: ['https://assets.codepen.io/21542/howler-death.mp3'],
        volume: 0.2
      })
    };
  }

  playJump() {
    this.sounds.jump.play();
  }

  playCollect() {
    this.sounds.collect.play();
  }

  playHit() {
    this.sounds.hit.play();
  }
}