import { Player } from './Player';
import { Platform } from './Platform';
import { Collectible } from './Collectible';
import { Enemy } from './Enemy';
import { SoundManager } from './SoundManager';

export class GameState {
  player: Player;
  platforms: Platform[];
  collectibles: Collectible[];
  enemies: Enemy[];
  score: number;
  canvas: HTMLCanvasElement | null;
  soundManager: SoundManager;
  level: number;

  constructor() {
    this.soundManager = new SoundManager();
    this.player = new Player(100, 100, this.soundManager);
    this.platforms = [];
    this.collectibles = [];
    this.enemies = [];
    this.score = 0;
    this.canvas = null;
    this.level = 1;
  }

  init(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.player = new Player(canvas.width / 2, canvas.height - 100, this.soundManager);
    this.initLevel();
  }

  initLevel() {
    if (!this.canvas) return;

    this.platforms = [
      new Platform(100, this.canvas.height - 200, 200, 20),
      new Platform(400, this.canvas.height - 300, 200, 20),
      new Platform(700, this.canvas.height - 400, 200, 20),
      new Platform(200, this.canvas.height - 500, 200, 20),
      new Platform(500, this.canvas.height - 600, 200, 20),
    ];

    this.collectibles = [
      new Collectible(150, this.canvas.height - 250, 'star'),
      new Collectible(450, this.canvas.height - 350, 'planet'),
      new Collectible(750, this.canvas.height - 450, 'star'),
      new Collectible(250, this.canvas.height - 550, 'planet'),
    ];

    this.enemies = [
      new Enemy(400, this.canvas.height - 340),
      new Enemy(700, this.canvas.height - 440),
    ];
  }

  handleKeyDown(code: string) {
    switch (code) {
      case 'ArrowLeft':
        this.player.moveLeft();
        break;
      case 'ArrowRight':
        this.player.moveRight();
        break;
      case 'Space':
        this.player.jump();
        break;
    }
  }

  handleKeyUp(code: string) {
    switch (code) {
      case 'ArrowLeft':
      case 'ArrowRight':
        this.player.stopMoving();
        break;
    }
  }

  update(deltaTime: number) {
    if (!this.canvas) return;

    this.player.update(deltaTime, this.canvas);

    // Update enemies
    this.enemies.forEach(enemy => enemy.update(deltaTime));

    // Update collectibles
    this.collectibles.forEach(collectible => collectible.update(deltaTime));

    // Check platform collisions
    this.platforms.forEach(platform => {
      if (platform.collidesWith(this.player)) {
        // If player is falling and above the platform
        if (this.player.velocityY > 0 && this.player.y + this.player.height - this.player.velocityY <= platform.y) {
          this.player.y = platform.y - this.player.height;
          this.player.velocityY = 0;
          this.player.isJumping = false;
        }
      }
    });

    // Check collectible collisions
    this.collectibles.forEach(collectible => {
      if (!collectible.collected && collectible.collidesWith(this.player)) {
        collectible.collected = true;
        this.score += collectible.type === 'star' ? 10 : 20;
        this.soundManager.playCollect();
      }
    });

    // Check enemy collisions
    if (!this.player.isInvulnerable) {
      this.enemies.forEach(enemy => {
        if (enemy.collidesWith(this.player)) {
          this.score = Math.max(0, this.score - 50);
          this.player.makeInvulnerable();
          this.soundManager.playHit();
        }
      });
    }

    // Check if all collectibles are collected
    if (this.collectibles.every(c => c.collected)) {
      this.level++;
      this.initLevel();
    }
  }

  render(ctx: CanvasRenderingContext2D) {
    // Clear canvas
    ctx.fillStyle = '#111827';
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);

    // Draw stars (background)
    for (let i = 0; i < 100; i++) {
      ctx.fillStyle = '#ffffff';
      const size = Math.random() * 2 + 1;
      ctx.fillRect(
        Math.random() * ctx.canvas.width,
        Math.random() * ctx.canvas.height,
        size,
        size
      );
    }

    // Render game elements
    this.platforms.forEach(platform => platform.render(ctx));
    this.collectibles.forEach(collectible => collectible.render(ctx));
    this.enemies.forEach(enemy => enemy.render(ctx));
    this.player.render(ctx);

    // Render HUD
    ctx.fillStyle = '#ffffff';
    ctx.font = '24px Arial';
    ctx.fillText(`Score: ${this.score}`, 20, 40);
    ctx.fillText(`Level: ${this.level}`, 20, 70);
  }
}