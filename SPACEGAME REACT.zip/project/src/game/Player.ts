import { SoundManager } from './SoundManager';

export class Player {
  x: number;
  y: number;
  width: number;
  height: number;
  velocityX: number;
  velocityY: number;
  isJumping: boolean;
  moveSpeed: number;
  jumpForce: number;
  gravity: number;
  soundManager: SoundManager;
  isInvulnerable: boolean;
  invulnerableTimer: number;

  constructor(x: number, y: number, soundManager: SoundManager) {
    this.x = x;
    this.y = y;
    this.width = 40;
    this.height = 60;
    this.velocityX = 0;
    this.velocityY = 0;
    this.isJumping = false;
    this.moveSpeed = 300;
    this.jumpForce = -500;
    this.gravity = 1000;
    this.soundManager = soundManager;
    this.isInvulnerable = false;
    this.invulnerableTimer = 0;
  }

  update(deltaTime: number, canvas: HTMLCanvasElement) {
    // Update position based on velocity
    this.x += this.velocityX * deltaTime;
    this.y += this.velocityY * deltaTime;

    // Apply gravity
    this.velocityY += this.gravity * deltaTime;

    // Update invulnerability timer
    if (this.isInvulnerable) {
      this.invulnerableTimer -= deltaTime;
      if (this.invulnerableTimer <= 0) {
        this.isInvulnerable = false;
      }
    }

    // Keep player in bounds
    if (this.x < 0) this.x = 0;
    if (this.x + this.width > canvas.width) this.x = canvas.width - this.width;
    if (this.y < 0) this.y = 0;
    if (this.y + this.height > canvas.height) {
      this.y = canvas.height - this.height;
      this.velocityY = 0;
      this.isJumping = false;
    }
  }

  render(ctx: CanvasRenderingContext2D) {
    if (this.isInvulnerable && Math.floor(Date.now() / 100) % 2 === 0) {
      return; // Skip rendering every other frame when invulnerable
    }

    // Draw astronaut body
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(this.x, this.y, this.width, this.height);

    // Draw helmet visor
    ctx.fillStyle = '#4299e1';
    ctx.fillRect(this.x + 5, this.y + 5, this.width - 10, 20);

    // Draw backpack
    ctx.fillStyle = '#e5e5e5';
    ctx.fillRect(this.x - 5, this.y + 20, 10, 30);
  }

  moveLeft() {
    this.velocityX = -this.moveSpeed;
  }

  moveRight() {
    this.velocityX = this.moveSpeed;
  }

  stopMoving() {
    this.velocityX = 0;
  }

  jump() {
    if (!this.isJumping) {
      this.velocityY = this.jumpForce;
      this.isJumping = true;
      this.soundManager.playJump();
    }
  }

  makeInvulnerable() {
    this.isInvulnerable = true;
    this.invulnerableTimer = 2; // 2 seconds of invulnerability
  }
}