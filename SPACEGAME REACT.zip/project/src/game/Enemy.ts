export class Enemy {
  x: number;
  y: number;
  width: number;
  height: number;
  velocityX: number;
  startX: number;
  range: number;
  speed: number;

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.width = 40;
    this.height = 40;
    this.velocityX = 100;
    this.startX = x;
    this.range = 200;
    this.speed = 100;
  }

  update(deltaTime: number) {
    this.x += this.velocityX * deltaTime;

    if (this.x > this.startX + this.range) {
      this.velocityX = -this.speed;
    } else if (this.x < this.startX) {
      this.velocityX = this.speed;
    }
  }

  render(ctx: CanvasRenderingContext2D) {
    // Draw enemy body
    ctx.fillStyle = '#ff0000';
    ctx.beginPath();
    ctx.moveTo(this.x + this.width / 2, this.y);
    ctx.lineTo(this.x + this.width, this.y + this.height);
    ctx.lineTo(this.x, this.y + this.height);
    ctx.closePath();
    ctx.fill();

    // Draw enemy eyes
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(this.x + this.width * 0.3, this.y + this.height * 0.3, 5, 0, Math.PI * 2);
    ctx.arc(this.x + this.width * 0.7, this.y + this.height * 0.3, 5, 0, Math.PI * 2);
    ctx.fill();
  }

  collidesWith(player: { x: number; y: number; width: number; height: number }) {
    return (
      player.x < this.x + this.width &&
      player.x + player.width > this.x &&
      player.y < this.y + this.height &&
      player.y + player.height > this.y
    );
  }
}