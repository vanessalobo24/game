export class Collectible {
  x: number;
  y: number;
  size: number;
  collected: boolean;
  rotation: number;
  type: 'star' | 'planet';
  color: string;

  constructor(x: number, y: number, type: 'star' | 'planet') {
    this.x = x;
    this.y = y;
    this.size = type === 'star' ? 20 : 30;
    this.collected = false;
    this.rotation = 0;
    this.type = type;
    this.color = type === 'star' ? '#ffd700' : '#ff4500';
  }

  update(deltaTime: number) {
    this.rotation += deltaTime * 2;
  }

  render(ctx: CanvasRenderingContext2D) {
    if (this.collected) return;

    ctx.save();
    ctx.translate(this.x + this.size / 2, this.y + this.size / 2);
    ctx.rotate(this.rotation);

    if (this.type === 'star') {
      this.renderStar(ctx);
    } else {
      this.renderPlanet(ctx);
    }

    ctx.restore();
  }

  private renderStar(ctx: CanvasRenderingContext2D) {
    const spikes = 5;
    const outerRadius = this.size / 2;
    const innerRadius = this.size / 4;

    ctx.beginPath();
    for (let i = 0; i < spikes * 2; i++) {
      const radius = i % 2 === 0 ? outerRadius : innerRadius;
      const angle = (i * Math.PI) / spikes;
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fillStyle = this.color;
    ctx.fill();
  }

  private renderPlanet(ctx: CanvasRenderingContext2D) {
    ctx.beginPath();
    ctx.arc(0, 0, this.size / 2, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.fill();
    
    // Add rings
    ctx.beginPath();
    ctx.ellipse(0, 0, this.size * 0.7, this.size * 0.2, Math.PI / 4, 0, Math.PI * 2);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  collidesWith(player: { x: number; y: number; width: number; height: number }) {
    if (this.collected) return false;
    return (
      player.x < this.x + this.size &&
      player.x + player.width > this.x &&
      player.y < this.y + this.size &&
      player.y + player.height > this.y
    );
  }
}